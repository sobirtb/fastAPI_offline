from fasthtml.common import *


# Initialize FastHTML app with fast reload
app,rt = fast_app(live=True)
    

# Route to display the contact list
@rt('/')
def get():
    # Create fake contacts
    contacts = [
        {"name": "John Doe", "email": "john.doe@example.com"},
        {"name": "Jane Smith", "email": "jane.smith@example.com"},
        {"name": "Alice Johnson", "email": "alice.johnson@example.com"},
        {"name": "Bob Williams", "email": "bob.williams@example.com"},
        {"name": "Emma Brown", "email": "emma.brown@example.com"}
    ]

    items = Ul(*[Li(o["name"]) for o in contacts])

    return Titled("Contact Book", Div(
        Ul(*items),
        H2("Add a new contact:"),
        Form(
            Input(name="name", placeholder="Name"),
            Input(name="email", placeholder="Email"),
            Button("Add Contact")
        )
    )
    )


# Start the server
serve()