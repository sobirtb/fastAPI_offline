from fasthtml.common import *


# Initialize FastHTML app
app,rt = fast_app(live=True)
    

@rt('/')
def get():
    # return Div(
    #     H1("Hello World"),
    #     P("This is a paragraph"),
    #     Button("Click me", onclick="alert('Hello World')")
    # )
    
    return Titled("Contact Book", Div(
        H1("Hello World"),
        P("This is a paragraph"),
        Button("Click me", onclick="alert('Hello World')")
        )
    )


# Start the server
serve()